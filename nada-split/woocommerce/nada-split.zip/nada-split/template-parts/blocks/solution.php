<?php
$title = get_field('title');
?>
<section class="solution">
	<h2 class="marker text-center"><?php echo $title ?></h2>
</section>