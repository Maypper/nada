<?php
$title = get_field('title');
$p = get_field('p');
?>
<section class="solution-2">
	<h2 class="marker text-center"><?php echo $title ?></h2>
	<p class="text-center"><?php echo $p ?></p>
</section>