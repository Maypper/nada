<?php
$title = get_field('title');
$p = get_field('p');
?>
<section class="tubes">
	<div class="container">
		<h2 class="marker text-center"><?php echo $title ?></h2>
		<p><?php echo $p ?></p>
	</div>
</section>