<div class="faq__box">
	<div class="faq__head">
		<b><?php echo get_the_title(); ?></b>
	</div>
	<div class="faq__body">
		<?php the_content(); ?>
	</div>
</div>
